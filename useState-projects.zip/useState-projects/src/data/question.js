export const Questions = {
    Html:[
        {
            question:"What does HTML stand for?",
            options :["dont know","HyperMakupLanguage","HostMarkupLanguage","HypertextMarkupLanguage"],
            answer:"HypertextMarkupLanguage"
        },
        {
            question:"Which of the following is used to create a hyperlink in HTML?",
            options :["<img>","<link>","<a>","<href>"],
            answer:"<a>"
        },
        {
            question:" Which HTML tag is used to define an internal style sheet?",
            options :["<script>","<style>","<css>","<link>"],
            answer:"<style>"
        }
    ],
    Css:[
        {
            question:"What does CSS stand for?",
            options :["Creative Style Sheets"," Cascading Style Sheets","Computer Style Sheets","Colorful Style Sheets"],
            answer:" Cascading Style Sheets"
        },
        {
            question:"Which property is used to change the background color in CSS?",
            options :["color","background-color","bgcolor","background"],
            answer:"background-color"
        },
        {
            question:"How do you add a shadow to an element in CSS?",
            options :["box-shadow: 10px 10px 5px grey;","shadow: 10px 10px 5px grey;","element-shadow: 10px 10px 5px grey;","border-shadow: 10px 10px 5px grey;"],
            answer:"box-shadow: 10px 10px 5px grey;"
        }
    ],
    Bootstrap:[
        {
            question:"What is Bootstrap primarily used for?",
            options :["Server-side scripting","Front-end development","Database management","Machine learning"],
            answer:"Front-end development"
        },
        {
            question:"Which class provides a responsive fixed-width container in Bootstrap?",
            options :[".container-fluid",".container-fixed",".container",".box-container"],
            answer:".container"
        },
        {
            question:"What is the purpose of the Bootstrap grid system?",
            options :["To style forms","To create responsive layouts","To manage animations","To design headers"],
            answer:"To create responsive layouts"
        }
    ],
    Javascript:[
        {
            question:"What is the correct syntax for referring to an external script called app.js?",
            options :["<script name=app.js></script>","<script src=app.js></script>","<script href=app.js></script>","<script file=app.js></script>"],
            answer:"<script src=app.js></script>"
        },
        {
            question:"How do you declare a JavaScript variable?",
            options :["variable x;","let x;","var x;","Both B and C"],
            answer:"Both B and C"
        },
        {
            question:"Which built-in method is used to convert a string to an integer?",
            options :["parseInt()","Number()","toInteger()","parse()"],
            answer:"parseInt()"
        }
    ]
}
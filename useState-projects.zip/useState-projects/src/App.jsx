import React from 'react'
import Navbar from './components/Navbar'
// import QuizApp from './components/QuizApp'
import Footer from './components/Footer'
import Home from './pages/Home'
import About from './pages/About'
import Pricing from './pages/Pricing'
import Topics from './pages/Topics'
import PageNotFound from './pages/PageNotFound'
import { Routes,Route } from 'react-router-dom'

const App = () => {
  return (
    <>
    {/* navbar start */}
    <Navbar />
    {/* navbar end */}

    {/* routing setup start */}
    <Routes>{/* it will ensure there is only one route that matches the path is rendered in ui */}
     <Route path='/' element={<Home/>} />
     <Route path="/about"  element={<About/>}/>
     <Route path='/pricing' element={<Pricing/>}/>
     <Route path="/topics" element={<Topics/>}/>
     <Route path="*" element={<PageNotFound/>}/>
    </Routes>

    {/* routing setup end */}
    <Footer />
    </>
  )
}

export default App
import React from 'react'

const Topics = () => {
  return (
    <div>
        
        <h1 className='topics-h1'>Take One Quiz Everyday and become an expert in all things in the world</h1>
        <img src={"./topics2.webp"} alt="topics image" width={"100%"} height={"550px"}/>

        <h2 className='topics-h2'>Here are the all Topics to Gain Your Knowledge</h2>
        <section>
            <h1>General Knowledge & Trivia:</h1>
            <ul>
                <li>Movies & TV Specific genres, actors, directors, quotes</li>
                <li>Music Genres, artists, songs, albums</li>
                <li>Sports Specific sports, teams, players, events</li>
                <li>Gaming Video games, consoles, characters, esports</li>
            </ul>
        </section>
        <section>
            <h1>Technical Skill Quizes</h1>
            <ul>
                <li>HTML -HyperText Markup Language</li>
                <li>CSS -Cascading Style Sheets</li>
                <li>Bootstrap CSS Framework</li>
                <li>JavaScript</li>
            </ul>
        </section>
        <section>
            <h1>Specific Knowledge Areas</h1>
            <ul>
                <li>Space & Astronomy</li>
                <li>Environmental Science</li>
                <li>Military & Wars</li>
                <li>Languages & Linguistics</li>
            </ul>
        </section>
        <img src={"./topics.webp"} alt="topics image lost in space" width={"100%"}/>
    </div>
  )
}

export default Topics
import React from 'react'
import QuizApp from '../components/QuizApp'


const Home = () => {
  return (
    <section className="home">
        
        <img src={"./quiz_winner.png"} alt="" width={"100%"} height={"200px"} className='img1 mb-3' style={{marginTop:"45px"}}/>
        <QuizApp/>
        <div className="container">
            <div className="box1 my-3">
                <h1 className='fs-4 fw-bolder home-header'>Play to Gain Your Knowledge</h1>
                <p className='home-para'>Quizzes offer an engaging and interactive way to learn, making knowledge acquisition fun. They encourage active recall, strengthening memory and understanding of various subjects. Quizzes can also highlight areas where you need to improve, guiding further learning and expanding your knowledge base.</p>
            </div>
            <div className="box2">
                {/* <h1>Popular Game🔥</h1> */}
                <div className='row justify-content-center'>
                    <div className="card1 col-md-6 col-sm-12">
                        <h1 className='card-h'>HTML5</h1>
                        <p className='card-p'>"HTML is the foundational markup language used to create the structure and content of web pages."</p>
                        <img src={"./html.png"} alt=""  />
                        <button className='card-btn text-center'>Play</button>
                    </div>
                    <div className="card1 card2 col-md-6 col-sm-12">
                        <h1 className='card-h'>CSS3</h1>
                        <p className='card-p'>CSS is a style sheet language used to describe the presentation of a document written in HTML or XML, including colors, layout, and fonts.</p>
                        <img src={"./css-quiz.png"} alt=""  />
                        <button className='card-btn text-center'>Play</button>
                    </div>
                </div>
                <div className='row justify-content-center'>
                    <div className="card1 card3 col-md-6 col-sm-12">
                        <h1 className='card-h'>Bootstrap</h1>
                        <p className='card-p'>Bootstrap is a free and open-source CSS framework that provides pre-designed HTML, CSS, and JavaScript components for rapidly developing responsive</p>
                        <img src={"./what-is-bootstrap.jpg"} alt="" />
                        <button className='card-btn text-center'>Play</button>
                    </div>
                    <div className="card1 card4 col-md-6 colo-sm-12">
                        <h1 className='card-h'>JavaScript</h1>
                        <p className='card-p'>JavaScript is a versatile scripting language that enables interactive and dynamic web pages, enhancing user experience and functionality.</p>
                        <img src={"./js2.avif"} alt="" />
                        <button className='card-btn text-center'>Play</button>
                    </div>
                </div>
                
            </div>
        </div>
        
        
    </section>

  )
}

export default Home
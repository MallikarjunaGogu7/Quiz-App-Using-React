import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      <img src={"error.avif"} alt="404 error page" width={"100%"} height={"800px"}/>
    </div>
  )
}

export default PageNotFound
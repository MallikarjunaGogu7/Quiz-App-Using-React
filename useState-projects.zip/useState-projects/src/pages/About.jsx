import React from 'react'

const About = () => {
  return (
    <div className='about'>
        <img src={"about1.webp"} alt=""  width={"100%"}/>
        <div className='row justify-content-center'>
            <div className='col-sm-6 d-flex justify-content-center align-items-center text-center' >
              <h2 className='about-h'>Welcome to GoQuiz, the ultimate trivia experience! We're passionate about making learning fun and engaging. Our app features thousands of meticulously crafted questions across a wide range of topics.
              </h2>
            </div>
            <div className='col-sm-6'><img src={"about2.jpg"} alt="" width={"100%"}/></div>
        </div>
        
        <img src={"about3.jpg"} alt="" width={"100%"}/>
    </div>
  )
}

export default About
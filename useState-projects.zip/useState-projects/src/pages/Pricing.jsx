import React from 'react'

const Pricing = () => {
  return (
    <div>
        <img src={"./pricing.avif"} alt="pricing image" width={"100%"} height={"700px"} />
    </div>
  )
}

export default Pricing